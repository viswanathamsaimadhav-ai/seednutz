# Seednutz — Component Specifications

Detailed visual specs and code references for every UI component in the Seednutz storefront.

---

## Layout Components

---

### `SiteLayout`
**File:** `components/layout/SiteLayout.jsx`

```
┌─────────────────────────────────┐
│  Navbar (fixed, z-50)           │  h-20
├─────────────────────────────────┤
│                                 │
│  <Outlet /> (page content)      │  min-h-screen pt-20
│                                 │
├─────────────────────────────────┤
│  Footer                         │
└─────────────────────────────────┘
```

---

### `Navbar`
**File:** `components/layout/Navbar.jsx`

```
┌─────────────────────────────────────────────────────┐
│  SEED[NUT]Z          Home Products About Contact 🛒 │  h-20
└─────────────────────────────────────────────────────┘
  ↑ font-display          ↑ tracking-widest uppercase

States:
- Transparent (top of page)
- bg-background/95 backdrop-blur-md border-b (scrolled > 40px)
- Mobile: hamburger menu, full-width dropdown
```

**Props:** none (reads cart from context, location from router)

---

### `Footer`
**File:** `components/layout/Footer.jsx`

```
┌─────────────────────────────────────────┐
│  SEEDNUTZ logo + tagline                │
│  Nav links   Brand links   Contact      │  border-t border-border
│  © 2024 Seednutz                        │
└─────────────────────────────────────────┘
```

---

## Home Page Components

---

### `HeroSection`
**File:** `components/home/HeroSection.jsx`

```
┌─────────────────────────────────────────┐
│                                         │
│  [Background image + dark overlay]      │  min-h-screen
│                                         │
│    ──── PURE NUTRITION ────             │  eyebrow: tracking-[0.4em] primary
│    From Earth                           │  font-display 6xl–8xl
│    To Energy                            │
│                                         │
│    [Explore Products →]  [Our Story →]  │  buttons
│                                         │
└─────────────────────────────────────────┘
       ↑ gradient fade at bottom
```

---

### `BrandStory`
**File:** `components/home/BrandStory.jsx`

```
┌──────────────────┬──┬──────────────────┐
│  Our Philosophy  │  │  Content text    │  py-24
│  "From Earth     │  │  Brand stats:    │
│   to Energy"     │  │  100% Natural    │
│  font-display    │ ┃│  28+ Products    │
│  4xl–6xl         │  │  12 Countries    │
└──────────────────┴──┴──────────────────┘
```

---

### `FeaturedCategories`
**File:** `components/home/FeaturedCategories.jsx`

```
┌────────┬────────┬────────┬────────┐
│ [Nuts] │[Seeds] │[Trail] │[Butters│  grid-cols-2 md:grid-cols-4
│  img   │  img   │  img   │  img   │  aspect-square
│ NUTS ↗ │SEEDS ↗ │ MIX ↗  │BUTTERS↗│  hover: scale-105
└────────┴────────┴────────┴────────┘
```

---

### `ProductHighlights`
**File:** `components/home/ProductHighlights.jsx`

```
Featured Products ────────── [View All Products →]

┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐
│ img  │ │ img  │ │ img  │ │ img  │  grid-cols-2 lg:grid-cols-4
│ Cat  │ │ Cat  │ │ Cat  │ │ Cat  │  gap-8
│ Name │ │ Name │ │ Name │ │ Name │
└──────┘ └──────┘ └──────┘ └──────┘
```

---

### `TrustIndicators`
**File:** `components/home/TrustIndicators.jsx`

```
┌──────────────┬──────────────┬──────────────┬──────────────┐
│  [Icon]      │  [Icon]      │  [Icon]      │  [Icon]      │  py-16
│  Title       │  Title       │  Title       │  Title       │  border-t/b
│  Description │  Description │  Description │  Description │  border-border
└──────────────┴──────────────┴──────────────┴──────────────┘
       grid-cols-2 md:grid-cols-4 gap-8
```

---

### `CTASection`
**File:** `components/home/CTASection.jsx`

```
┌─────────────────────────────────────────┐
│         DISCOVER THE RANGE              │  py-24
│   Our Complete Collection of           │  text-center
│   Premium Nuts & Seeds                 │
│                                         │
│  [Explore Products]  [Contact Us →]    │
└─────────────────────────────────────────┘
```

---

## Product Components

---

### `ProductCard`
**File:** `components/products/ProductCard.jsx`

```
┌─────────────────────┐
│                     │  aspect-square
│  [PRODUCT IMAGE]    │  bg-card border border-border/50
│                     │  hover: scale-105 (duration-700)
│ [Nutrient Badge]    │  ← absolute top-4 left-4
│              [🛒]   │  ← absolute bottom-2 right-2, opacity-0 hover:opacity-100
├─────────────────────┤
│ CATEGORY            │  text-[10px] tracking-[0.3em] uppercase text-primary
│ Product Name        │  font-display text-lg
│ Short description   │  text-sm text-muted-foreground line-clamp-2
│ [tag] [tag] [tag]   │  border border-border text-[10px]
│ $12.99              │  text-sm font-medium
└─────────────────────┘
```

**Props:**
| Prop | Type | Description |
|------|------|-------------|
| `product` | Object | Product entity record |
| `index` | Number | Used for stagger animation delay |

---

### `FilterEngine`
**File:** `components/products/FilterEngine.jsx`

```
┌─────────────────────────────────────────────────────┐
│  CATEGORY            FLAVOR           DIETARY        │  border-t/b
│  [Nuts] [Seeds]      [Original]       [Vegan]        │  py-6
│  [Trail Mix]         [Honey Roasted]  [Gluten Free]  │
│  [Nut Butters]       [Spicy]          [Keto]         │
│                                       [Clear All]    │
└─────────────────────────────────────────────────────┘
  Active tag: bg-primary/10 border-primary text-primary
  Inactive:   border-border text-muted-foreground
```

**Props:**
| Prop | Type | Description |
|------|------|-------------|
| `filters` | Object | `{ category, flavor, dietary }` |
| `onChange` | Function | Called with updated filters |

---

### `SearchBar`
**File:** `components/products/SearchBar.jsx`

```
┌──────────────────────────────────────────┐
│ 🔍  Search products...                   │  h-12 border border-border
└──────────────────────────────────────────┘
     ↑ Search icon absolute left-4
```

---

### `NutritionPanel`
**File:** `components/products/NutritionPanel.jsx`

```
┌──────────────────────────────┐
│ Nutrition Facts               │  border border-border
│ Serving Size: 28g             │
├──────────────────────────────┤
│ Calories              170     │  font-bold, text-lg
├──────────────────────────────┤
│ Total Fat              15g    │
│   Saturated Fat         1g    │  ← pl-4 (indented)
│   Trans Fat             0g    │  ← pl-4
│ Total Carbohydrates     6g    │
│   Dietary Fiber         3g    │  ← pl-4
│   Total Sugars          1g    │  ← pl-4
│ Protein                 6g    │
│ Sodium                  0mg   │
│ Calcium                 8%    │
│ Iron                    6%    │
└──────────────────────────────┘
```

---

### `IngredientMap`
**File:** `components/products/IngredientMap.jsx`

```
INGREDIENT MAP ──────────────────

┌─────────────────────────────┬──┐
│ Organic Almonds              │∨ │  border border-border
└─────────────────────────────┴──┘
┌─────────────────────────────────┐
│  SOURCE                         │  expanded: animated height
│  California, USA                │
│  HEALTH BENEFIT                 │
│  Rich in vitamin E              │
└─────────────────────────────────┘
┌─────────────────────────────┬──┐
│ Honey                        │∨ │
└─────────────────────────────┴──┘
```

---

## Cart & Checkout Components

---

### Cart Page Layout
**File:** `pages/Cart.jsx`

```
CART ─────────────────────────────

┌──────────────────────────┬────────────────┐
│  Product items list      │  ORDER SUMMARY │
│                          │                │
│  [img] Name       [$]    │  Item × qty  $ │
│        Category          │  ─────────     │
│        [−][2][+] [🗑️]    │  Subtotal   $  │
│                          │  TOTAL      $  │
│  ─────────────────       │                │
│  [img] Name       [$]    │  [Checkout →]  │
│        [−][1][+] [🗑️]    │                │
└──────────────────────────┴────────────────┘
  lg:col-span-8              lg:col-span-4 sticky
```

---

### Checkout Page Layout
**File:** `pages/Checkout.jsx`

```
CHECKOUT ─────────────────────────

┌──────────────────────────┬────────────────┐
│  SHIPPING DETAILS        │  ORDER SUMMARY │
│  Full Name  │  Email     │  Items list    │
│  Address               │  ─────────     │
│  City  │ State  │ ZIP  │  Subtotal   $  │
│                          │  Shipping  TBD │
│  PAYMENT                 │  TOTAL      $  │
│  ┌─────────────────────┐ │                │
│  │ Stripe CardElement  │ │  [← Back]      │
│  └─────────────────────┘ │                │
│                          │                │
│  [🔒 Pay $XX.XX]         │                │
└──────────────────────────┴────────────────┘
  lg:col-span-8              lg:col-span-4 sticky
```

**Success State:**
```
┌──────────────────────────────┐
│         ☑                    │  border border-border
│    Order Confirmed           │  text-center
│    Thank you message         │
│    [← Continue Shopping]     │
└──────────────────────────────┘
```

---

## Admin Components

---

### `AdminLogin`
**File:** `pages/AdminLogin.jsx`

```
         ── SECURE ACCESS ──
         
         Admin Login
         Sign in to manage the Seednutz storefront

┌─────────────────────────────────┐
│  USERNAME                       │  border border-border
│  [👤 Enter username           ] │  h-12 bg-card
│                                 │
│  PASSWORD                       │
│  [🔒 Enter password           ] │
│                                 │
│  [Sign In                    →] │  bg-primary h-12
└─────────────────────────────────┘
         Authorized personnel only
```

---

### `AdminGuard`
**File:** `components/AdminGuard.jsx`

**Logic Flow:**
```
Mount → Check localStorage["seednutz_admin_auth"]
  ├── "true"  → render children
  └── other   → <Navigate to="/admin-login" replace />
```

---

## Page Layouts

---

### Home (`/`)
```
HeroSection          min-h-screen full-bleed image
BrandStory           py-24 max-w-7xl
FeaturedCategories   py-16 max-w-7xl
ProductHighlights    py-16 max-w-7xl
TrustIndicators      py-16 border-t border-b
CTASection           py-24
```

### Products (`/products`)
```
Header               border-b py-16
SearchBar            sticky below header
FilterEngine         collapsible panel
Product Grid         grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4
Loading Skeleton     animated pulse placeholders
Empty State          centered message + reset link
```

### Product Detail (`/products/:id`)
```
Breadcrumb           border-b py-4
  └── ← Back to Products

12-col grid:
  col-span-5 sticky:
    Main image       aspect-square
    Gallery strip    w-20 h-20 thumbnails

  col-span-7:
    Category label
    Product name     text-4xl lg:text-5xl
    Nutrient USP badge
    Description
    Dietary tags
    Benefits list
    Price            text-3xl text-primary
    Packaging
    Quantity + Add to Cart
    ─────────────────
    IngredientMap
    NutritionPanel
    Inquiry CTA block

Related Products     border-t pt-16 4-col grid
```

---

## States & Feedback

### Loading States
```jsx
// Spinner (full page)
<div className="min-h-screen pt-20 flex items-center justify-center">
  <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
</div>

// Skeleton cards (product grid)
{[...Array(8)].map((_, i) => (
  <div key={i} className="animate-pulse">
    <div className="aspect-square bg-muted mb-4" />
    <div className="h-3 bg-muted w-1/3 mb-2" />
    <div className="h-4 bg-muted w-3/4 mb-2" />
    <div className="h-3 bg-muted w-1/2" />
  </div>
))}
```

### Empty States
```jsx
// No products matching filter
<div className="py-20 text-center">
  <p className="font-display text-2xl mb-4">No products found</p>
  <p className="text-muted-foreground font-body mb-8">
    Try adjusting your filters or search term
  </p>
  <button onClick={resetFilters} className="text-primary ...">
    Clear Filters
  </button>
</div>
```

### Error States
```jsx
// Form inline error
{error && (
  <div className="flex items-center gap-2 text-sm text-destructive font-body">
    <AlertCircle size={14} />
    {error}
  </div>
)}
```

### Success States
```jsx
// Contact form success
<div className="text-center py-12">
  <CheckCircle className="text-primary mx-auto mb-4" size={40} />
  <h3 className="font-display text-2xl mb-2">Message Sent</h3>
  <p className="text-muted-foreground font-body">We'll get back to you shortly.</p>
</div>
```

---

## Z-Index Scale

| Layer | z-index | Usage |
|-------|---------|-------|
| Base | `z-0` | Default |
| Sticky | `z-10` | Sticky elements |
| Overlay | `z-40` | Modals, drawers |
| Navbar | `z-50` | Fixed navigation |

---

## Accessibility Notes

- All interactive elements have visible focus states (`focus:border-primary`)
- Images always have `alt` attributes
- Buttons have `aria-label` when icon-only
- Form inputs have associated labels
- Color contrast: all text meets WCAG AA on dark backgrounds
- Keyboard navigation supported throughout
- `ScrollToTop` resets focus on route change