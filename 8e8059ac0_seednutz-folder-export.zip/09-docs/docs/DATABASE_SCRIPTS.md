# Seednutz — Database Scripts

Executable database scripts for seeding, managing, and maintaining the Seednutz Product and Inquiry entities.

> **How to run:** These scripts use the Base44 SDK. Execute them via the platform's code execution environment, or adapt them as backend functions.

---

## 📋 Table of Contents

1. [Seed Products](#1-seed-products)
2. [Seed Sample Inquiries](#2-seed-sample-inquiries)
3. [Clear All Data](#3-clear-all-data)
4. [Update Product Prices](#4-update-product-prices)
5. [Bulk Update Featured Status](#5-bulk-update-featured-status)
6. [Migrate / Backfill Fields](#6-migrate--backfill-fields)
7. [Export Products to JSON](#7-export-products-to-json)
8. [Inquiry Management](#8-inquiry-management)
9. [Database Health Check](#9-database-health-check)

---

## 1. Seed Products

Seeds the database with the full Seednutz product catalog.

```js
// scripts/seed-products.js
import { base44 } from "@/api/base44Client";

const products = [
  {
    name: "Organic Raw Almonds",
    slug: "organic-raw-almonds",
    category: "nuts",
    flavor: "original",
    price: 12.99,
    short_description: "California-grown, sun-ripened purity",
    description: "Premium organic almonds sourced from sustainable California orchards. Each batch is carefully selected for size, freshness, and natural flavor profile.",
    image_url: "",
    dietary_tags: ["vegan", "gluten_free", "sugar_free", "organic", "non_gmo", "keto"],
    nutrient_usp: "6g Protein",
    is_featured: true,
    ingredients: [
      { name: "Organic Almonds", source: "California, USA", benefit: "Rich in vitamin E and healthy monounsaturated fats" }
    ],
    nutrition_facts: {
      serving_size: "28g (about 23 nuts)",
      calories: 170,
      total_fat: "15g",
      saturated_fat: "1g",
      trans_fat: "0g",
      cholesterol: "0mg",
      sodium: "0mg",
      total_carbohydrates: "6g",
      dietary_fiber: "3g",
      total_sugars: "1g",
      protein: "6g",
      calcium: "8%",
      iron: "6%"
    },
    benefits: ["Heart-healthy fats", "Good source of protein", "Rich in vitamin E"],
    packaging_details: "12 oz resealable pouch"
  },
  {
    name: "Honey Roasted Cashews",
    slug: "honey-roasted-cashews",
    category: "nuts",
    flavor: "honey_roasted",
    price: 14.99,
    short_description: "Golden, crunchy, naturally sweet",
    description: "Whole cashews roasted to perfection and glazed with pure honey for a sweet, satisfying crunch.",
    image_url: "",
    dietary_tags: ["gluten_free", "non_gmo"],
    nutrient_usp: "5g Protein",
    is_featured: true,
    ingredients: [
      { name: "Cashews", source: "Vietnam", benefit: "Source of copper and magnesium" },
      { name: "Honey", source: "Local apiaries", benefit: "Natural energy source" }
    ],
    nutrition_facts: {
      serving_size: "28g (about 18 nuts)",
      calories: 160,
      total_fat: "13g",
      saturated_fat: "2.5g",
      total_carbohydrates: "9g",
      total_sugars: "4g",
      protein: "5g"
    },
    benefits: ["Energy boost", "Mineral-rich", "Antioxidant properties"],
    packaging_details: "10 oz resealable pouch"
  },
  {
    name: "Roasted Pumpkin Seeds",
    slug: "roasted-pumpkin-seeds",
    category: "seeds",
    flavor: "salted",
    price: 8.99,
    short_description: "Mineral-dense, satisfyingly crunchy",
    description: "Lightly salted pumpkin seeds roasted in small batches for maximum crunch and flavor.",
    image_url: "",
    dietary_tags: ["vegan", "gluten_free", "sugar_free", "high_protein", "non_gmo", "keto"],
    nutrient_usp: "9g Protein",
    is_featured: true,
    ingredients: [
      { name: "Pumpkin Seeds", source: "USA", benefit: "High in magnesium and zinc" },
      { name: "Sea Salt", source: "Mediterranean", benefit: "Essential minerals" }
    ],
    nutrition_facts: {
      serving_size: "28g",
      calories: 150,
      total_fat: "13g",
      total_carbohydrates: "5g",
      dietary_fiber: "2g",
      protein: "9g",
      iron: "15%",
      magnesium: "40%"
    },
    benefits: ["Immune support", "Bone health", "High protein"],
    packaging_details: "8 oz resealable pouch"
  },
  {
    name: "Trail Mix Energy Blend",
    slug: "trail-mix-energy-blend",
    category: "trail_mix",
    flavor: "original",
    price: 11.99,
    short_description: "Fuel for the adventurous",
    description: "A balanced blend of almonds, cashews, pumpkin seeds, and dried cranberries for sustained energy.",
    image_url: "",
    dietary_tags: ["gluten_free", "high_protein", "non_gmo"],
    nutrient_usp: "7g Protein",
    is_featured: true,
    ingredients: [
      { name: "Almonds", source: "California, USA", benefit: "Heart-healthy fats" },
      { name: "Cashews", source: "Vietnam", benefit: "Mineral-rich" },
      { name: "Pumpkin Seeds", source: "USA", benefit: "High in magnesium" },
      { name: "Dried Cranberries", source: "Wisconsin, USA", benefit: "Antioxidant-rich" }
    ],
    nutrition_facts: {
      serving_size: "30g",
      calories: 140,
      total_fat: "9g",
      total_carbohydrates: "11g",
      dietary_fiber: "2g",
      total_sugars: "5g",
      protein: "7g"
    },
    benefits: ["Sustained energy", "Trail-ready nutrition", "Antioxidant blend"],
    packaging_details: "16 oz resealable pouch"
  },
  {
    name: "Dark Chocolate Almond Butter",
    slug: "dark-chocolate-almond-butter",
    category: "nut_butters",
    flavor: "chocolate",
    price: 13.99,
    short_description: "Spreadable indulgence",
    description: "Smooth almond butter blended with rich dark chocolate for a decadent yet nutritious spread.",
    image_url: "",
    dietary_tags: ["vegan", "gluten_free", "organic"],
    nutrient_usp: "4g Protein",
    is_featured: false,
    ingredients: [
      { name: "Roasted Almonds", source: "California, USA", benefit: "Healthy fats and protein" },
      { name: "Dark Chocolate", source: "Fair-trade Ecuador", benefit: "Flavonoid antioxidants" },
      { name: "Coconut Sugar", source: "Philippines", benefit: "Low-glycemic sweetener" }
    ],
    nutrition_facts: {
      serving_size: "2 tbsp (32g)",
      calories: 190,
      total_fat: "16g",
      total_carbohydrates: "10g",
      total_sugars: "6g",
      protein: "4g"
    },
    benefits: ["Antioxidant-rich", "Satisfying", "Naturally sweetened"],
    packaging_details: "12 oz glass jar"
  },
  {
    name: "Spicy Smoked Almonds",
    slug: "spicy-smoked-almonds",
    category: "roasted_blends",
    flavor: "spicy",
    price: 10.99,
    short_description: "Smoky heat with a crunch",
    description: "Almonds smoked over natural hickory wood and dusted with a bold spice blend.",
    image_url: "",
    dietary_tags: ["vegan", "gluten_free", "sugar_free", "keto", "non_gmo"],
    nutrient_usp: "6g Protein",
    is_featured: false,
    ingredients: [
      { name: "Almonds", source: "California, USA", benefit: "Protein and healthy fats" },
      { name: "Hickory Smoke", source: "Natural wood", benefit: "Natural flavoring" },
      { name: "Spice Blend", source: "Paprika, cayenne, garlic", benefit: "Metabolism boost" }
    ],
    nutrition_facts: {
      serving_size: "28g",
      calories: 170,
      total_fat: "15g",
      total_carbohydrates: "6g",
      dietary_fiber: "3g",
      protein: "6g",
      sodium: "180mg"
    },
    benefits: ["Bold flavor", "Metabolism-friendly", "Low carb"],
    packaging_details: "8 oz resealable pouch"
  },
  {
    name: "Sunflower Seeds — Original",
    slug: "sunflower-seeds-original",
    category: "seeds",
    flavor: "plain",
    price: 6.99,
    short_description: "Classic, clean, crunchy",
    description: "Hulled sunflower seeds lightly roasted with a touch of sea salt.",
    image_url: "",
    dietary_tags: ["vegan", "gluten_free", "sugar_free", "non_gmo", "keto"],
    nutrient_usp: "6g Protein",
    is_featured: false,
    ingredients: [
      { name: "Sunflower Seeds", source: "North Dakota, USA", benefit: "Vitamin E and selenium" },
      { name: "Sea Salt", source: "Mediterranean", benefit: "Essential minerals" }
    ],
    nutrition_facts: {
      serving_size: "28g",
      calories: 160,
      total_fat: "14g",
      total_carbohydrates: "6g",
      dietary_fiber: "3g",
      protein: "6g",
      vitamin_e: "50%"
    },
    benefits: ["Skin health", "Antioxidant-rich", "Heart-healthy"],
    packaging_details: "10 oz resealable pouch"
  },
  {
    name: "Protein Snack Bars — Almond & Seed",
    slug: "protein-snack-bars-almond-seed",
    category: "snack_bars",
    flavor: "original",
    price: 15.99,
    short_description: "On-the-go nutrition",
    description: "Dense, satisfying snack bars packed with almonds, seeds, and natural protein.",
    image_url: "",
    dietary_tags: ["gluten_free", "high_protein", "non_gmo"],
    nutrient_usp: "10g Protein",
    is_featured: true,
    ingredients: [
      { name: "Almonds", source: "California, USA", benefit: "Healthy fats and protein" },
      { name: "Pumpkin Seeds", source: "USA", benefit: "Magnesium and zinc" },
      { name: "Honey", source: "Local apiaries", benefit: "Natural binder and energy" },
      { name: "Chia Seeds", source: "South America", benefit: "Omega-3 and fiber" }
    ],
    nutrition_facts: {
      serving_size: "1 bar (40g)",
      calories: 180,
      total_fat: "9g",
      total_carbohydrates: "16g",
      dietary_fiber: "4g",
      total_sugars: "8g",
      protein: "10g"
    },
    benefits: ["High protein", "Sustained energy", "Convenient nutrition"],
    packaging_details: "Box of 6 bars"
  },
  {
    name: "Savory Herb Walnuts",
    slug: "savory-herb-walnuts",
    category: "roasted_blends",
    flavor: "savory_herb",
    price: 12.99,
    short_description: "Herb-crusted, omega-rich",
    description: "Premium walnuts roasted with a blend of rosemary, thyme, and sea salt.",
    image_url: "",
    dietary_tags: ["vegan", "gluten_free", "sugar_free", "keto", "non_gmo"],
    nutrient_usp: "4g Protein",
    is_featured: false,
    ingredients: [
      { name: "Walnuts", source: "California, USA", benefit: "Omega-3 fatty acids" },
      { name: "Rosemary", source: "Mediterranean", benefit: "Antioxidant and anti-inflammatory" },
      { name: "Thyme", source: "Mediterranean", benefit: "Antimicrobial properties" }
    ],
    nutrition_facts: {
      serving_size: "28g",
      calories: 190,
      total_fat: "18g",
      total_carbohydrates: "4g",
      dietary_fiber: "2g",
      protein: "4g"
    },
    benefits: ["Brain health", "Omega-3 rich", "Anti-inflammatory"],
    packaging_details: "8 oz resealable pouch"
  },
  {
    name: "Chia Seeds — Organic",
    slug: "chia-seeds-organic",
    category: "seeds",
    flavor: "plain",
    price: 9.99,
    short_description: "Tiny seeds, mighty nutrition",
    description: "Certified organic chia seeds, a nutritional powerhouse rich in omega-3s and fiber.",
    image_url: "",
    dietary_tags: ["vegan", "gluten_free", "sugar_free", "high_protein", "organic", "non_gmo", "keto"],
    nutrient_usp: "5g Omega-3",
    is_featured: false,
    ingredients: [
      { name: "Organic Chia Seeds", source: "South America", benefit: "Omega-3, fiber, and complete protein" }
    ],
    nutrition_facts: {
      serving_size: "28g (about 2 tbsp)",
      calories: 140,
      total_fat: "9g",
      total_carbohydrates: "12g",
      dietary_fiber: "10g",
      protein: "5g",
      calcium: "18%",
      iron: "12%"
    },
    benefits: ["Omega-3 rich", "High fiber", "Complete protein source"],
    packaging_details: "12 oz resealable pouch"
  }
];

async function seedProducts() {
  console.log(`Seeding ${products.length} products...`);
  const created = await base44.entities.Product.bulkCreate(products);
  console.log(`✅ Created ${created.length} products`);
  return created;
}

seedProducts();
```

---

## 2. Seed Sample Inquiries

```js
// scripts/seed-inquiries.js
import { base44 } from "@/api/base44Client";

const inquiries = [
  {
    full_name: "Sarah Mitchell",
    email: "sarah@wholefoods.co",
    phone: "+1-555-0100",
    inquiry_type: "wholesale",
    message: "We're interested in carrying your trail mix line in our 12 store locations. Can you provide wholesale pricing and minimum order quantities?",
    status: "new"
  },
  {
    full_name: "James Chen",
    email: "james@distribution.com",
    phone: "+1-555-0200",
    inquiry_type: "distribution",
    message: "We operate a regional distribution network in the Pacific Northwest and would like to explore a partnership for distributing your products.",
    status: "in_progress"
  },
  {
    full_name: "Emily Rodriguez",
    email: "emily.r@gmail.com",
    phone: "",
    inquiry_type: "feedback",
    message: "Absolutely love your honey roasted cashews! The quality is unmatched. Any plans for a subscription service?",
    status: "resolved"
  },
  {
    full_name: "Michael Thompson",
    email: "mike@fitgym.com",
    phone: "+1-555-0300",
    inquiry_type: "partnership",
    message: "Our gym chain is looking for clean-label protein snacks for our retail area. Interested in a co-branded snack bar?",
    status: "new"
  },
  {
    full_name: "Lisa Park",
    email: "lisa.park@email.com",
    phone: "",
    inquiry_type: "general",
    message: "Are your products certified kosher? I couldn't find the certification on the packaging.",
    status: "new"
  }
];

async function seedInquiries() {
  console.log(`Seeding ${inquiries.length} inquiries...`);
  const created = await base44.entities.Inquiry.bulkCreate(inquiries);
  console.log(`✅ Created ${created.length} inquiries`);
  return created;
}

seedInquiries();
```

---

## 3. Clear All Data

> ⚠️ **Warning:** This permanently deletes all records. Use with caution.

```js
// scripts/clear-all.js
import { base44 } from "@/api/base44Client";

async function clearAll() {
  console.log("⚠️  Deleting ALL products and inquiries...");

  const productCount = await base44.entities.Product.list();
  console.log(`Found ${productCount.length} products to delete`);
  await base44.entities.Product.deleteMany({});
  console.log("✅ All products deleted");

  const inquiryCount = await base44.entities.Inquiry.list();
  console.log(`Found ${inquiryCount.length} inquiries to delete`);
  await base44.entities.Inquiry.deleteMany({});
  console.log("✅ All inquiries deleted");
}

clearAll();
```

---

## 4. Update Product Prices

Bulk update prices for specific products:

```js
// scripts/update-prices.js
import { base44 } from "@/api/base44Client";

const priceUpdates = [
  { slug: "organic-raw-almonds", price: 13.49 },
  { slug: "honey-roasted-cashews", price: 15.49 },
  { slug: "trail-mix-energy-blend", price: 12.49 }
];

async function updatePrices() {
  for (const update of priceUpdates) {
    const [product] = await base44.entities.Product.filter({ slug: update.slug });
    if (product) {
      await base44.entities.Product.update(product.id, { price: update.price });
      console.log(`✅ Updated ${product.name}: $${update.price}`);
    } else {
      console.log(`❌ Product not found: ${update.slug}`);
    }
  }
}

updatePrices();
```

---

## 5. Bulk Update Featured Status

```js
// scripts/update-featured.js
import { base44 } from "@/api/base44Client";

async function setAllFeatured(value) {
  const result = await base44.entities.Product.updateMany(
    {},
    { $set: { is_featured: value } }
  );
  console.log(`✅ Set is_featured=${value} for all products`);
  return result;
}

async function setCategoryFeatured(category, value) {
  const result = await base44.entities.Product.updateMany(
    { category },
    { $set: { is_featured: value } }
  );
  console.log(`✅ Set is_featured=${value} for category: ${category}`);
  return result;
}

// Set all nuts as featured
setCategoryFeatured("nuts", true);
```

---

## 6. Migrate / Backfill Fields

Add a new field to all existing products:

```js
// scripts/backfill-field.js
import { base44 } from "@/api/base44Client";

async function backfillPriceRange() {
  const products = await base44.entities.Product.list();

  const updates = products.map((p) => {
    let price_range = "$";
    if (p.price >= 15) price_range = "$$$";
    else if (p.price >= 10) price_range = "$$";

    return { id: p.id, price_range };
  });

  const result = await base44.entities.Product.bulkUpdate(updates);
  console.log(`✅ Backfilled price_range for ${updates.length} products`);
  return result;
}

backfillPriceRange();
```

---

## 7. Export Products to JSON

```js
// scripts/export-products.js
import { base44 } from "@/api/base44Client";

async function exportProducts() {
  const products = await base44.entities.Product.list('-created_date', 100);

  const exportData = products.map((p) => ({
    name: p.name,
    slug: p.slug,
    category: p.category,
    flavor: p.flavor,
    price: p.price,
    dietary_tags: p.dietary_tags,
    is_featured: p.is_featured,
    nutrient_usp: p.nutrient_usp
  }));

  console.log(JSON.stringify(exportData, null, 2));
  console.log(`\n✅ Exported ${exportData.length} products`);
  return exportData;
}

exportProducts();
```

---

## 8. Inquiry Management

### List Inquiries by Status
```js
// scripts/manage-inquiries.js
import { base44 } from "@/api/base44Client";

async function listInquiriesByStatus() {
  const statuses = ["new", "in_progress", "resolved"];

  for (const status of statuses) {
    const inquiries = await base44.entities.Inquiry.filter({ status });
    console.log(`\n📋 ${status.toUpperCase()} (${inquiries.length}):`);
    inquiries.forEach((i) => {
      console.log(`  - ${i.full_name} (${i.email}) — ${i.inquiry_type}`);
    });
  }
}

listInquiriesByStatus();
```

### Mark All New Inquiries as In Progress
```js
async function processNewInquiries() {
  const result = await base44.entities.Inquiry.updateMany(
    { status: "new" },
    { $set: { status: "in_progress" } }
  );
  console.log("✅ All new inquiries moved to in_progress");
  return result;
}

processNewInquiries();
```

### Delete Resolved Inquiries Older Than X Days
```js
async function cleanupOldInquiries() {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 90); // 90 days ago

  const result = await base44.entities.Inquiry.deleteMany({
    status: "resolved",
    created_date: { $lt: cutoff.toISOString() }
  });
  console.log("✅ Cleaned up old resolved inquiries");
  return result;
}

cleanupOldInquiries();
```

---

## 9. Database Health Check

```js
// scripts/health-check.js
import { base44 } from "@/api/base44Client";

async function healthCheck() {
  console.log("🔍 Running database health check...\n");

  // Product stats
  const products = await base44.entities.Product.list('-created_date', 200);
  console.log(`📦 Products: ${products.length} total`);

  const featured = products.filter((p) => p.is_featured);
  console.log(`   ⭐ Featured: ${featured.length}`);

  const categories = [...new Set(products.map((p) => p.category))];
  console.log(`   📂 Categories: ${categories.join(", ")}`);

  const missingPrices = products.filter((p) => p.price == null);
  console.log(`   ⚠️  Missing prices: ${missingPrices.length}`);

  const missingImages = products.filter((p) => !p.image_url);
  console.log(`   ⚠️  Missing images: ${missingImages.length}`);

  const missingNutrition = products.filter((p) => !p.nutrition_facts);
  console.log(`   ⚠️  Missing nutrition facts: ${missingNutrition.length}`);

  // Inquiry stats
  const inquiries = await base44.entities.Inquiry.list('-created_date', 200);
  console.log(`\n📧 Inquiries: ${inquiries.length} total`);

  const byStatus = {
    new: inquiries.filter((i) => i.status === "new").length,
    in_progress: inquiries.filter((i) => i.status === "in_progress").length,
    resolved: inquiries.filter((i) => i.status === "resolved").length
  };
  console.log(`   New: ${byStatus.new} | In Progress: ${byStatus.in_progress} | Resolved: ${byStatus.resolved}`);

  console.log("\n✅ Health check complete");
  return { products: products.length, inquiries: inquiries.length, byStatus };
}

healthCheck();
```

---

## 📝 Usage Notes

1. **Running scripts:** Execute these via the Base44 platform's code execution environment or as backend functions.
2. **Bulk operations:** `bulkCreate` and `bulkUpdate` support up to 500 records per call.
3. **updateMany:** Uses MongoDB update operators (`$set`, `$unset`, `$inc`, etc.). The `$set` must change a field in the query filter to avoid infinite re-matching.
4. **deleteMany:** Use specific queries — an empty `{}` query deletes everything.
5. **Realtime:** Use `subscribe()` for live updates in the UI — no polling needed.
6. **Built-in fields:** Every record has `id`, `created_date`, `updated_date`, `created_by_id` — never declare these in your data.