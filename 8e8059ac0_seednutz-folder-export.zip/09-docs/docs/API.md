# Seednutz — API Documentation

Complete API reference for the Seednutz storefront, covering the Base44 SDK (entities, auth, integrations) and Stripe payment flow.

---

## 📦 Base44 SDK Client

The SDK is pre-initialized and imported from:

```js
import { base44 } from "@/api/base44Client";
```

All entity operations, auth, and integrations are accessed through this client.

---

## 🗄 Entities API

Entities are accessed via `base44.entities.<EntityName>`. Each entity supports the following operations:

### Product Entity

```js
const Product = base44.entities.Product;
```

#### List All Products
```js
// List all products (default sort, up to 50)
const products = await Product.list();

// List with sort and limit
const products = await Product.list('-created_date', 20);
```

#### Filter Products
```js
// Filter by single field
const nuts = await Product.filter({ category: "nuts" });

// Filter by multiple fields
const featured = await Product.filter({
  category: "nuts",
  is_featured: true
}, '-created_date', 10);

// Filter by dietary tag (array contains)
const vegan = await Product.filter({ dietary_tags: "vegan" });
```

#### Get Single Product
```js
// By ID (filter returns array, take first)
const [product] = await Product.filter({ id: productId });
```

#### Create Product
```js
const newProduct = await Product.create({
  name: "Organic Almonds",
  slug: "organic-almonds",
  category: "nuts",
  flavor: "original",
  price: 12.99,
  description: "Premium organic almonds...",
  short_description: "Raw, organic, California-grown",
  image_url: "https://...",
  dietary_tags: ["vegan", "gluten_free", "organic", "non_gmo"],
  nutrient_usp: "6g Protein per serving",
  is_featured: true,
  ingredients: [
    { name: "Almonds", source: "California, USA", benefit: "Rich in vitamin E" }
  ],
  nutrition_facts: {
    serving_size: "28g (about 23 nuts)",
    calories: 170,
    total_fat: "15g",
    protein: "6g",
    // ... see Product schema for full fields
  },
  benefits: ["Heart-healthy fats", "Good source of protein"],
  packaging_details: "12 oz resealable pouch"
});
```

#### Bulk Create Products
```js
const created = await Product.bulkCreate([
  { name: "Product A", category: "nuts", price: 9.99 },
  { name: "Product B", category: "seeds", price: 7.99 }
]);
```

#### Update Product
```js
const updated = await Product.update(productId, {
  price: 14.99,
  is_featured: true
});
```

#### Bulk Update (same change to all matches)
```js
await Product.updateMany(
  { category: "nuts" },
  { $set: { is_featured: false } }
);
```

#### Bulk Update (different change per record)
```js
await Product.bulkUpdate([
  { id: id1, price: 10.99 },
  { id: id2, price: 12.99 }
]);
```

#### Delete Product
```js
await Product.delete(productId);
```

#### Delete Multiple
```js
await Product.deleteMany({ category: "discontinued" });
```

#### Get Schema
```js
const schema = await Product.schema();
// Returns JSON schema (minus built-in fields)
```

#### Realtime Subscription
```js
useEffect(() => {
  const unsubscribe = Product.subscribe((event) => {
    // event: { id, type: 'create'|'update'|'delete', data }
    if (event.type === 'create') {
      setProducts(prev => [event.data, ...prev]);
    }
  });
  return () => unsubscribe();
}, []);
```

---

### Inquiry Entity

```js
const Inquiry = base44.entities.Inquiry;
```

#### Create Inquiry (Contact Form)
```js
const inquiry = await Inquiry.create({
  full_name: "Jane Doe",
  email: "jane@example.com",
  phone: "+1-555-0100",
  inquiry_type: "wholesale",
  message: "Interested in bulk pricing for our retail chain.",
  status: "new"
});
```

#### List Inquiries
```js
const inquiries = await Inquiry.list('-created_date', 50);
```

#### Filter Inquiries by Status
```js
const newInquiries = await Inquiry.filter({ status: "new" });
const inProgress = await Inquiry.filter({ status: "in_progress" });
const resolved = await Inquiry.filter({ status: "resolved" });
```

#### Update Inquiry Status
```js
await Inquiry.update(inquiryId, { status: "in_progress" });
await Inquiry.update(inquiryId, { status: "resolved" });
```

#### Delete Inquiry
```js
await Inquiry.delete(inquiryId);
```

---

### User Entity (Built-in)

```js
const User = base44.entities.User;
```

> **Note:** User records cannot be created via the SDK. Users join via invites.

#### List Users
```js
const users = await User.list();
```

#### Invite User
```js
await base44.users.inviteUser("newuser@example.com", "user");
// Roles: "user" or "admin"
```

---

## 🔐 Auth API

### Check Authentication
```js
const isAuthed = await base44.auth.isAuthenticated();
// Returns: boolean
```

### Get Current User
```js
const user = await base44.auth.me();
// Returns: { id, email, full_name, role, ... }
```

### Update Current User
```js
await base44.auth.updateMe({
  // Custom fields only — built-ins (id, email, full_name, role) cannot be overridden
});
```

### Logout
```js
await base44.auth.logout("/");
// Redirects to "/" after logout
```

### Redirect to Login
```js
base44.auth.redirectToLogin("/dashboard");
// Redirects to login, then back to /dashboard
```

### Email/Password Login
```js
await base44.auth.loginViaEmailPassword(email, password);
// Sets token, then hard redirect:
window.location.href = "/";
```

### OAuth Login
```js
await base44.auth.loginWithProvider("google", "/");
// Providers: "google" | "facebook" | "microsoft" | "apple"
```

### Register
```js
await base44.auth.register({ email, password });
// Does NOT log in — user is unverified
// Flow: register → OTP → verifyOtp → setToken → redirect
```

### Verify OTP
```js
const { access_token } = await base44.auth.verifyOtp({ email, otpCode });
// Then set token and redirect
```

### Resend OTP
```js
await base44.auth.resendOtp(email);
```

### Password Reset
```js
await base44.auth.resetPasswordRequest(email);
await base44.auth.resetPassword({ resetToken, newPassword });
```

---

## 🔌 Integrations API

All integrations are accessed via `base44.integrations.Core.<Endpoint>`.

### InvokeLLM — AI Text Generation
```js
const result = await base44.integrations.Core.InvokeLLM({
  prompt: "Describe the health benefits of almonds",
  add_context_from_internet: true,  // Only with gemini models
  response_json_schema: {
    type: "object",
    properties: {
      benefits: { type: "array", items: { type: "string" } }
    }
  },
  model: "automatic"  // or: gpt_5_mini, gemini_3_flash, claude_sonnet_4_6, etc.
});
```

**Models:**
| Model | Use Case |
|-------|----------|
| `automatic` (default) | General tasks (gpt-4o-mini) |
| `gemini_3_flash` | Web search + fast responses |
| `gemini_3_1_pro` | Web search + high quality |
| `claude_sonnet_4_6` | Complex reasoning |
| `gpt_5_5` | Advanced reasoning |

> `add_context_from_internet` only works with `gemini_3_flash` and `gemini_3_1_pro`.

### UploadFile — Public File Upload
```js
const { file_url } = await base44.integrations.Core.UploadFile({
  file: fileObject  // File from input
});
// Returns: { file_url: string }
```

### UploadPrivateFile — Private File Upload
```js
const { file_uri } = await base44.integrations.Core.UploadPrivateFile({
  file: fileObject
});
// Returns: { file_uri: string }
```

### CreateFileSignedUrl — Signed Download URL
```js
const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
  file_uri: "private-file-uri",
  expires_in: 300  // seconds
});
```

### GenerateImage — AI Image Generation
```js
const { url } = await base44.integrations.Core.GenerateImage({
  prompt: "Extreme macro photo of roasted almonds, chiaroscuro lighting",
  existing_image_urls: ["https://..."]  // optional reference
});
```

### GenerateVideo — AI Video Generation
```js
const { url } = await base44.integrations.Core.GenerateVideo({
  prompt: "Cinematic shot of nuts falling in slow motion",
  duration: 6,  // 4, 6, or 8 seconds
  aspect_ratio: "16:9"  // or "9:16"
});
```

### GenerateSpeech — Text-to-Speech
```js
const { url } = await base44.integrations.Core.GenerateSpeech({
  text: "Welcome to Seednutz",
  voice: "river",  // river, honey, sunny, storm, spark
  language_code: "en"  // optional, auto-detected
});
```

### TranscribeAudio — Speech-to-Text
```js
const transcript = await base44.integrations.Core.TranscribeAudio({
  audio_url: fileUrl  // Upload first via UploadFile
});
// Returns: string
```

### SendEmail
```js
await base44.integrations.Core.SendEmail({
  to: "customer@example.com",
  subject: "Your Seednutz Inquiry",
  body: "Thank you for contacting us...",
  from_name: "Seednutz"  // optional, defaults to app name
});
```

### ExtractDataFromUploadedFile
```js
const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
  file_url: uploadedFileUrl,
  json_schema: {
    type: "object",
    properties: {
      name: { type: "string" },
      price: { type: "number" }
    }
  }
});
// Returns: { status, details, output }
```

---

## 💳 Stripe Payment API

### Frontend (Stripe Elements)

```js
import { loadStripe } from "@stripe/stripe-js";
import { Elements, CardElement, useStripe, useElements } from "@stripe/react-stripe-js";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);
```

#### Create Payment Method
```js
const stripe = useStripe();
const elements = useElements();

const { error, paymentMethod } = await stripe.createPaymentMethod({
  type: "card",
  card: elements.getElement(CardElement),
  billing_details: {
    name: "John Doe",
    email: "john@example.com",
    address: {
      line1: "123 Main St",
      city: "New York",
      state: "NY",
      postal_code: "10001"
    }
  }
});
```

### Environment Variables
```
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_xxxxx
```

Stripe secret key is registered via Base44 secrets for server-side PaymentIntent creation.

---

## 📊 Analytics API

Track custom events:

```js
base44.analytics.track({
  eventName: "product_added_to_cart",
  properties: {
    product_id: "xxx",
    product_name: "Organic Almonds",
    price: 12.99
  }
});
```

---

## 🔄 React Query Integration

The app uses TanStack React Query for data fetching:

```js
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

// Fetch products
const { data: products, isLoading } = useQuery({
  queryKey: ["products"],
  queryFn: () => base44.entities.Product.list('-created_date', 50)
});

// Fetch single product
const { data: product } = useQuery({
  queryKey: ["product", id],
  queryFn: async () => {
    const items = await base44.entities.Product.filter({ id });
    return items[0];
  }
});

// Create product with cache invalidation
const queryClient = useQueryClient();
const mutation = useMutation({
  mutationFn: (data) => base44.entities.Product.create(data),
  onSuccess: () => queryClient.invalidateQueries({ queryKey: ["products"] })
});
```

---

## 🌐 REST Endpoints (Base44 Auto-Generated)

Base44 auto-generates REST endpoints for each entity:

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/entities/Product` | List products |
| GET | `/api/entities/Product/:id` | Get single product |
| POST | `/api/entities/Product` | Create product |
| PUT | `/api/entities/Product/:id` | Update product |
| DELETE | `/api/entities/Product/:id` | Delete product |
| GET | `/api/entities/Inquiry` | List inquiries |
| POST | `/api/entities/Inquiry` | Create inquiry |
| PUT | `/api/entities/Inquiry/:id` | Update inquiry |
| DELETE | `/api/entities/Inquiry/:id` | Delete inquiry |

> These endpoints are available when the app is deployed. Authentication is handled by the Base44 platform.

---

## 📝 Error Handling

Entity operations throw on error. In user-facing flows, wrap in try/catch:

```js
try {
  const product = await base44.entities.Product.create(data);
  toast({ title: "Product created successfully" });
} catch (error) {
  toast({ title: "Failed to create product", variant: "destructive" });
}
```

For data-fetching flows (React Query), let errors bubble up — they surface in the `error` field of `useQuery`.