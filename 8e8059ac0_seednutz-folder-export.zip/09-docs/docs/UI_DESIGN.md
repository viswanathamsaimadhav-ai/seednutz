# Seednutz — UI Design System
## Tectonic Vitality × Obsidian Harvest

---

## 🎨 Design Philosophy

**Tectonic Vitality** is a premium editorial design system inspired by high-end food photography, geological textures, and harvest aesthetics. The system uses extreme contrast, dramatic lighting metaphors, and a restrained color palette to communicate premium quality and nutritional integrity.

**Core Principles:**
- **Chiaroscuro** — High-contrast light/dark interplay; dramatic visual tension
- **Editorial restraint** — White space, typography-first hierarchy
- **Mineral precision** — Sharp edges, no decorative flourishes, functional ornament only
- **Harvest warmth** — Golden amber accents against obsidian darkness

---

## 🌈 Color Palette

### Primary Colors

| Token | CSS Variable | HSL Value | Hex | Usage |
|-------|-------------|-----------|-----|-------|
| `background` | `--background` | `hsl(0 0% 7%)` | `#121212` | Page background |
| `foreground` | `--foreground` | `hsl(40 10% 96%)` | `#F5F5F1` | Primary text |
| `primary` | `--primary` | `hsl(42 95% 49%)` | `#F2A900` | Accent, CTAs, highlights |
| `primary-foreground` | `--primary-foreground` | `hsl(0 0% 7%)` | `#121212` | Text on primary bg |

### Surface Colors

| Token | CSS Variable | HSL Value | Hex | Usage |
|-------|-------------|-----------|-----|-------|
| `card` | `--card` | `hsl(0 0% 10%)` | `#1A1A1A` | Card backgrounds |
| `muted` | `--muted` | `hsl(0 0% 14%)` | `#242424` | Subtle backgrounds |
| `muted-foreground` | `--muted-foreground` | `hsl(0 0% 55%)` | `#8C8C8C` | Secondary text |
| `border` | `--border` | `hsl(0 0% 18%)` | `#2E2E2E` | Dividers, borders |
| `secondary` | `--secondary` | `hsl(80 30% 22%)` | `#3A4A2A` | Olive green accent |

### Semantic Colors

| Token | Usage |
|-------|-------|
| `destructive` | Error states, delete actions |
| `ring` | Focus rings (matches primary) |
| `input` | Input borders (matches border) |

### Color Usage Rules
- **Never use white** (`#FFFFFF`) — use `foreground` (`#F5F5F1`) instead
- **Never use pure black** — use `background` (`#121212`)
- **Primary (amber)** is used sparingly: category labels, CTAs, price highlights, active states
- **Borders** create structure; avoid box shadows — use borders instead

---

## 🔤 Typography

### Font Families

| Role | Font | Weight | CSS Class |
|------|------|--------|-----------|
| Display / Heading | Playfair Display | 400–900 | `font-display`, `font-heading` |
| Body / UI | Inter | 300–700 | `font-body` |

**Import:** `@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,700&family=Inter:wght@300;400;500;600;700&display=swap');`

### Type Scale

| Level | Font | Size | Weight | Class | Usage |
|-------|------|------|--------|-------|-------|
| Hero | Playfair Display | 72–96px | 700 | `text-7xl lg:text-8xl font-display` | Hero headline |
| H1 | Playfair Display | 48–60px | 600 | `text-5xl lg:text-6xl font-display` | Page titles |
| H2 | Playfair Display | 36–48px | 600 | `text-3xl lg:text-4xl font-display` | Section titles |
| H3 | Playfair Display | 24–30px | 500 | `text-2xl font-display` | Card titles |
| H4 | Playfair Display | 18–20px | 500 | `text-xl font-display` | Subsection |
| Body Large | Inter | 18px | 400 | `text-lg font-body` | Intro paragraphs |
| Body | Inter | 14–16px | 400 | `text-sm font-body` | General content |
| Label | Inter | 10px | 400–500 | `text-[10px] font-body tracking-[0.3em] uppercase` | Category badges, labels |
| Caption | Inter | 12px | 400 | `text-xs font-body` | Meta, footnotes |

### Letter Spacing Patterns

| Pattern | Class | Usage |
|---------|-------|-------|
| Tight | default | Display headlines |
| Wide | `tracking-widest` | Button text, nav links |
| Ultra-wide | `tracking-[0.3em]` | Category labels |
| Extreme | `tracking-[0.4em]` | Section eyebrows |

---

## 📐 Spacing & Layout

### Max-Width Container
```
max-w-7xl mx-auto px-6 lg:px-8
```
- Mobile: 24px padding (`px-6`)
- Desktop: 32px padding (`lg:px-8`)
- Max width: 1280px (`max-w-7xl`)

### Section Padding
| Section Type | Padding |
|-------------|---------|
| Page hero/header | `py-16` to `py-24` |
| Content sections | `py-16` to `py-24` |
| Compact sections | `py-12` |
| Cards/panels | `p-8` |
| Compact cards | `p-6` |
| Form fields | `px-4 py-3` or `h-12` |

### Grid Systems
| Layout | Class |
|--------|-------|
| 2-column | `grid grid-cols-1 md:grid-cols-2 gap-8` |
| 3-column | `grid grid-cols-1 md:grid-cols-3 gap-8` |
| 4-column products | `grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8` |
| Product detail | `grid grid-cols-1 lg:grid-cols-12 gap-16` (5+7) |
| Categories | `grid grid-cols-2 md:grid-cols-4 gap-4` |

### Border Radius
The design system uses **near-zero radius** (0.25rem / 4px) for a precise, mineral aesthetic. No `rounded-lg` or `rounded-full` on structural elements.

```
--radius: 0.25rem
```
- Buttons: `rounded-none` (sharp)
- Inputs: `rounded-none`
- Cards: no radius (sharp corners)
- Badges/tags: no radius

---

## 🧩 Component Specs

### Navbar
```
Fixed top | Height: h-20 | z-50
Transparent → bg-background/95 backdrop-blur-md on scroll
Border: border-b border-border (on scroll)
Logo: font-display text-2xl tracking-wider | SEED + <primary>NUTZ</primary>
Nav links: text-sm font-body tracking-widest uppercase
Active: text-primary | Inactive: text-muted-foreground hover:text-foreground
Cart badge: w-5 h-5 bg-primary rounded-full text-[10px]
```

### Buttons

#### Primary Button
```
bg-primary text-primary-foreground
h-12 px-6
text-sm font-body tracking-widest uppercase
rounded-none
hover:bg-primary/90
transition-all
```

#### Ghost / Link Button
```
text-primary
text-sm font-body tracking-widest uppercase
inline-flex items-center gap-3
hover:gap-4 (arrow shift)
```

#### Icon Button
```
w-10 h-10 (or w-12 h-12)
flex items-center justify-center
border border-border
hover:bg-card
transition-colors
```

#### Quick-Add (on Product Card hover)
```
absolute bottom-2 right-2
w-8 h-8 bg-primary text-primary-foreground
opacity-0 group-hover:opacity-100 transition-opacity
```

### Product Card
```
group block relative
Image: aspect-square overflow-hidden bg-card border border-border/50 mb-4
Image hover: scale-105 (duration-700)
Category label: text-[10px] font-body tracking-[0.3em] uppercase text-primary
Name: font-display text-lg group-hover:text-primary (duration-300)
Description: text-sm text-muted-foreground line-clamp-2
Dietary tags: border border-border px-2 py-0.5 text-[10px] tracking-wider uppercase
Price: text-sm font-body font-medium
Nutrient badge: absolute top-4 left-4 bg-background/90 backdrop-blur-sm px-3 py-1.5 border border-border
```

### Inputs & Forms
```
Background: bg-card
Border: border border-border
Height: h-12
Text: text-sm font-body
Padding: px-4 (with icon: pl-11)
Focus: focus:border-primary (no ring)
Label: text-xs font-body tracking-[0.3em] uppercase text-muted-foreground mb-2
```

### Dietary / Category Tags (Small Badges)
```
border border-border
px-2 py-0.5 (small) or px-3 py-1.5 (medium)
text-[10px] font-body tracking-wider uppercase
text-muted-foreground (inactive) | text-primary + border-primary (active)
```

### Section Eyebrow / Label
```html
<p className="text-xs font-body tracking-[0.4em] uppercase text-primary mb-4">
  Section Label
</p>
```

### Divider
```html
<div className="h-px bg-border" />
```

### Nutrition Panel
```
Full-width border border-border
Header: font-display text-2xl font-bold + serving size
Nutrient rows: flex justify-between py-1.5 border-b border-border/50
Bold rows (calories): font-bold
Indented rows: pl-4 (sub-nutrients)
```

### Ingredient Map (Accordion)
```
Each item: border border-border
Button: px-5 py-4 flex justify-between hover:bg-card
Arrow: ChevronDown, rotate-180 when open
Content: px-5 pb-5 (animated height)
Sub-labels: text-[10px] tracking-[0.2em] uppercase text-muted-foreground
```

### Filter Panel
```
border-t border-b border-border py-6
FilterGroup: flex flex-wrap gap-2
Tag button: px-3 py-1.5 text-xs font-body tracking-wider uppercase
Inactive: border-border text-muted-foreground hover:border-foreground/30
Active: bg-primary/10 border-primary text-primary
```

---

## 🎞 Animation Patterns

All animations use **Framer Motion** with these standard patterns:

### Fade + Rise (Standard Entry)
```jsx
initial={{ opacity: 0, y: 20 }}
animate={{ opacity: 1, y: 0 }}
transition={{ duration: 0.6 }}
```

### Staggered List
```jsx
// Parent: staggerChildren
// Child:
initial={{ opacity: 0, y: 20 }}
animate={{ opacity: 1, y: 0 }}
transition={{ duration: 0.4, delay: index * 0.05 }}
```

### Viewport Scroll Trigger
```jsx
initial={{ opacity: 0, y: 40 }}
whileInView={{ opacity: 1, y: 0 }}
viewport={{ once: true }}
transition={{ duration: 0.8 }}
```

### Accordion (Height Animate)
```jsx
initial={{ height: 0, opacity: 0 }}
animate={{ height: "auto", opacity: 1 }}
exit={{ height: 0, opacity: 0 }}
transition={{ duration: 0.3 }}
```

### Mobile Menu
```jsx
initial={{ opacity: 0, height: 0 }}
animate={{ opacity: 1, height: "auto" }}
exit={{ opacity: 0, height: 0 }}
```

### Page Transition (Entry)
```jsx
initial={{ opacity: 0 }}
animate={{ opacity: 1 }}
transition={{ duration: 0.6 }}
```

---

## 📱 Responsive Breakpoints

| Breakpoint | Prefix | Width |
|-----------|--------|-------|
| Mobile | (default) | < 640px |
| Small | `sm:` | ≥ 640px |
| Medium | `md:` | ≥ 768px |
| Large | `lg:` | ≥ 1024px |
| Extra Large | `xl:` | ≥ 1280px |

### Mobile Patterns
- Single column → multi-column at `sm:` or `md:`
- Mobile menu: hamburger toggles full-width overlay
- Cart icon always visible on mobile
- Typography scales down: `text-5xl lg:text-6xl`
- Padding reduces: `px-6` (mobile) vs `lg:px-8` (desktop)

---

## 🖼 Imagery Guidelines

### Photography Style
- **Extreme macro** — Close-up, texture-rich, filling the frame
- **Chiaroscuro lighting** — Strong directional light, deep shadows
- **Dark backgrounds** — Product on dark/black surface
- **Shallow depth of field** — Sharp subject, blurred background
- **No lifestyle shots** — Product-only photography

### Image Formats
- **Product cards:** `aspect-square` (1:1)
- **Hero background:** Full bleed, `object-cover`, overlay gradient
- **Thumbnails:** `w-20 h-20` (80×80px)

### Overlays
```css
/* Dark gradient overlay on hero images */
background: linear-gradient(to bottom, rgba(18,18,18,0.4), rgba(18,18,18,0.9))
```

---

## 🏗 Page Layout Templates

### Standard Page
```
<Navbar fixed h-20>
<main pt-20>
  <!-- Header/Hero section -->
  <section border-b border-border>
    <div max-w-7xl mx-auto px-6 lg:px-8 py-16>
      <p eyebrow text-primary>
      <h1 font-display text-5xl lg:text-6xl>
        Word <span text-primary>Accent</span>
      </h1>
    </div>
  </section>

  <!-- Content sections -->
  <section>
    <div max-w-7xl mx-auto px-6 lg:px-8 py-16>
      <!-- Content -->
    </div>
  </section>
</main>
<Footer>
```

### Product Detail Layout
```
12-column grid:
- Image: lg:col-span-5 (sticky top-28)
- Info:  lg:col-span-7
```

### Checkout Layout
```
12-column grid:
- Form:    lg:col-span-8
- Summary: lg:col-span-4 (sticky top-28)
```

---

## 🔲 Icon Usage

All icons use **Lucide React** at these standard sizes:

| Context | Size | Class |
|---------|------|-------|
| Navigation | 18–20px | `size={18}` |
| Buttons (with text) | 14–16px | `size={14}` |
| Standalone actions | 16–20px | `size={16}` |
| Hero/Feature icons | 28–32px | `size={28}` |

**Icon colors:**
- Default: `text-muted-foreground`
- Active/primary: `text-primary`
- On dark bg: `text-foreground`

---

## 🎯 Design Tokens Quick Reference

```css
/* Paste in :root to override theme */
--background:        0 0% 7%;        /* #121212 */
--foreground:        40 10% 96%;     /* #F5F5F1 */
--primary:           42 95% 49%;     /* #F2A900 amber */
--card:              0 0% 10%;       /* #1A1A1A */
--muted:             0 0% 14%;       /* #242424 */
--muted-foreground:  0 0% 55%;       /* #8C8C8C */
--border:            0 0% 18%;       /* #2E2E2E */
--secondary:         80 30% 22%;     /* #3A4A2A olive */
--radius:            0.25rem;        /* 4px sharp */
--font-heading:      'Playfair Display', Georgia, serif;
--font-body:         'Inter', ui-sans-serif, system-ui, sans-serif;
--font-display:      'Playfair Display', Georgia, serif;
```

---

## 📋 Component Checklist

When building a new component, verify:

- [ ] Uses `font-display` or `font-body` — never hardcoded font-family
- [ ] Uses token classes (`bg-background`, `text-foreground`) — never hex values
- [ ] Uses `border-border` for all borders
- [ ] No box shadows — use borders for structure
- [ ] Sharp corners (`rounded-none`) on interactive elements
- [ ] Labels use `tracking-[0.3em] uppercase text-[10px]` pattern
- [ ] Hover states use `transition-colors duration-300` or `transition-all`
- [ ] Images have `object-cover` and defined aspect ratio
- [ ] Mobile-first with responsive breakpoints
- [ ] Framer Motion entry animation (fade + rise)