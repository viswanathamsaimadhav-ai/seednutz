# Seednutz — Brand Website & Storefront

A modern, responsive e-commerce showcase for **Seednutz**, a premium nuts & seeds brand. Built with the **Tectonic Vitality** design system featuring an **Obsidian Harvest** dark theme, the site includes a full product catalog with advanced filtering, nutritional transparency, a shopping cart, Stripe checkout, and an admin login gate.

---

## 🌰 Brand Overview

Seednutz is a premium nuts, seeds, and trail mix brand focused on nutritional transparency, sustainable sourcing, and clean ingredients. The website serves as both a brand showcase and a functional storefront.

---

## ✨ Features

### Storefront
- **Product Catalog** — Browse all products with category, flavor, and dietary filtering
- **Advanced Filtering** — Filter by category (nuts, seeds, trail mix, nut butters, snack bars, roasted blends), flavor, and dietary tags (vegan, gluten-free, sugar-free, high-protein, organic, keto, non-GMO)
- **Search** — Full-text search across product names and descriptions
- **Product Detail Pages** — Full product info including:
  - Ingredient Map (expandable source & health benefit per ingredient)
  - Nutrition Facts panel
  - Dietary tags & health benefits
  - Packaging details
  - Related products
- **Shopping Cart** — Add/remove items, adjust quantities, persistent via localStorage
- **Checkout** — Stripe-powered payment with shipping details collection
- **Nutritional Transparency** — Every product displays full nutrition facts and ingredient sourcing

### Admin
- **Admin Login** — Hardcoded credentials gate access to the entire site
- **Logout** — Session clearing with redirect to login

### Design
- **Tectonic Vitality Design System** — Obsidian Harvest dark theme
- **Typography** — Playfair Display (headings/display) + Inter (body)
- **Color Palette**:
  - Background: `#121212` (obsidian)
  - Foreground: `#F5F5F1` (harvest white)
  - Primary/Accent: `#F2A900` (golden amber)
  - Secondary: muted olive green
- **Animations** — Framer Motion for scroll-triggered reveals, hover effects, and page transitions
- **Responsive** — Mobile-first, fully responsive across all breakpoints

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | React 18 + Vite |
| Styling | Tailwind CSS + shadcn/ui |
| Animations | Framer Motion |
| Icons | Lucide React |
| Routing | React Router DOM v6 |
| Data Fetching | TanStack React Query |
| Backend / Database | Base44 BaaS |
| Payments | Stripe (Stripe.js + React Stripe Elements) |
| State Management | React Context (Cart) + localStorage |

---

## 📁 Project Structure

```
src/
├── App.jsx                    # Router & app entry point
├── index.css                  # Design tokens (Tectonic Vitality theme)
├── tailwind.config.js         # Tailwind theme config
│
├── pages/
│   ├── Home.jsx                # Landing page (composes home sections)
│   ├── Products.jsx            # Product catalog with filtering & search
│   ├── ProductDetail.jsx       # Single product view with nutrition & ingredients
│   ├── About.jsx               # Brand story, values & process
│   ├── Contact.jsx             # Inquiry form (saves to Inquiry entity + email)
│   ├── Cart.jsx                # Shopping cart with quantity controls
│   ├── Checkout.jsx            # Stripe checkout with shipping form
│   └── AdminLogin.jsx          # Hardcoded admin login gate
│
├── components/
│   ├── layout/
│   │   ├── SiteLayout.jsx      # Page wrapper (Navbar + Outlet + Footer)
│   │   ├── Navbar.jsx          # Sticky nav with cart badge & logout
│   │   └── Footer.jsx          # Site footer
│   │
│   ├── home/
│   │   ├── HeroSection.jsx     # Full-screen hero with brand tagline
│   │   ├── BrandStory.jsx      # Philosophy & brand stats
│   │   ├── FeaturedCategories.jsx  # Category navigation cards
│   │   ├── ProductHighlights.jsx  # Featured product grid
│   │   ├── TrustIndicators.jsx     # Brand value propositions
│   │   └── CTASection.jsx       # Call-to-action banner
│   │
│   ├── products/
│   │   ├── ProductCard.jsx     # Product card with quick-add to cart
│   │   ├── NutritionPanel.jsx  # Structured nutrition facts label
│   │   ├── IngredientMap.jsx   # Expandable ingredient source/benefit list
│   │   ├── FilterEngine.jsx    # Category/flavor/dietary filter panel
│   │   └── SearchBar.jsx       # Product search input
│   │
│   ├── AdminGuard.jsx          # Route guard (redirects to login if unauthed)
│   └── ScrollToTop.jsx         # Scroll reset on route change
│
├── lib/
│   ├── CartContext.jsx         # Cart provider (localStorage persistence)
│   ├── AuthContext.jsx         # Base44 auth context
│   └── query-client.js         # React Query client
│
├── entities/
│   ├── Product.json            # Product schema
│   └── Inquiry.json            # Customer inquiry schema
│
└── api/
    └── base44Client.js         # Pre-initialized Base44 SDK client
```

---

## 🗄 Data Model

### Product Entity
| Field | Type | Description |
|-------|------|-------------|
| `name` | string | Product name (required) |
| `slug` | string | URL-friendly identifier |
| `description` | string | Full product description |
| `short_description` | string | Brief tagline / USP |
| `image_url` | string | Main product image URL |
| `gallery_images` | string[] | Additional product images |
| `category` | enum | nuts, seeds, trail_mix, nut_butters, snack_bars, roasted_blends |
| `flavor` | enum | original, salted, honey_roasted, spicy, chocolate, savory_herb, smoked, plain |
| `price` | number | Price in USD |
| `dietary_tags` | string[] | vegan, gluten_free, sugar_free, high_protein, organic, keto, non_gmo |
| `ingredients` | object[] | Array of {name, source, benefit} |
| `nutrition_facts` | object | Per-serving nutrition data (calories, fat, carbs, protein, vitamins, etc.) |
| `benefits` | string[] | Health benefit highlights |
| `packaging_details` | string | Packaging size & type |
| `nutrient_usp` | string | Key nutrient highlight (e.g., "20g Protein") |
| `is_featured` | boolean | Featured on homepage |

### Inquiry Entity
| Field | Type | Description |
|-------|------|-------------|
| `full_name` | string | Contact name (required) |
| `email` | string | Contact email (required) |
| `phone` | string | Contact phone |
| `inquiry_type` | enum | general, wholesale, distribution, partnership, feedback, other |
| `message` | string | Inquiry message (required) |
| `status` | enum | new (default), in_progress, resolved |

---

## 🔐 Admin Authentication

The site is gated behind a simple admin login:

- **Login URL:** `/admin-login`
- **Username:** `admin`
- **Password:** `admin@123`

Authentication is handled via `localStorage` with the key `seednutz_admin_auth`. The `AdminGuard` component wraps all protected routes and redirects unauthenticated users to the login page. The logout button in the navbar clears the session and returns to login.

> **Note:** This is a lightweight client-side gate for demo/internal use. For production, replace with Base44's built-in auth system (email/password, OAuth, roles).

---

## 💳 Stripe Checkout

The checkout page uses Stripe Elements for secure card input:

1. **Cart** → User reviews items and clicks "Proceed to Checkout"
2. **Checkout** → User enters shipping details + card info via Stripe Elements
3. **Payment** → Stripe `createPaymentMethod` generates a payment method token
4. **Confirmation** → Order success screen displayed

### Stripe Configuration
Set these environment variables to enable live payments:
```
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_xxx
```
The Stripe secret key is registered via the Base44 secrets system for server-side PaymentIntent creation.

---

## 🎨 Design System

### Tectonic Vitality — Obsidian Harvest

The design system uses CSS custom properties defined in `index.css`, mapped to Tailwind utility classes in `tailwind.config.js`.

**Design Principles:**
- **Chiaroscuro lighting** — High-contrast, dramatic product photography aesthetic
- **Extreme macro photography** — Close-up, texture-rich imagery
- **Editorial typography** — Serif display fonts for headings, technical sans for body
- **Minimal ornamentation** — Sharp corners (0.25rem radius), border-driven UI
- **Golden accents** — Amber primary color used sparingly for emphasis

**Token Classes:**
- `bg-background`, `text-foreground` — Base colors
- `bg-primary`, `text-primary` — Amber accent
- `bg-card`, `bg-muted` — Surface colors
- `font-display`, `font-body` — Typography roles
- `border-border` — Border color

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation
```bash
npm install
npm run dev
```

### Build
```bash
npm run build
```

### Environment Variables
Create a `.env` file:
```
VITE_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
```

---

## 📱 Pages & Routes

| Route | Page | Description |
|-------|------|-------------|
| `/admin-login` | AdminLogin | Admin login gate (public) |
| `/` | Home | Landing page with hero, brand story, featured products |
| `/products` | Products | Full catalog with filtering & search |
| `/products/:id` | ProductDetail | Single product with nutrition & ingredients |
| `/about` | About | Brand story, values, process |
| `/contact` | Contact | Inquiry form |
| `/cart` | Cart | Shopping cart |
| `/checkout` | Checkout | Stripe payment |

All routes except `/admin-login` are protected by `AdminGuard`.

---

## 🧩 Key Components

### CartContext (`lib/CartContext.jsx`)
- Provides cart state across the app
- Persists to `localStorage` (key: `seednutz_cart`)
- Exposes: `items`, `addToCart`, `updateQuantity`, `removeFromCart`, `clearCart`, `itemCount`

### AdminGuard (`components/AdminGuard.jsx`)
- Checks `localStorage` for auth flag
- Redirects to `/admin-login` if unauthenticated
- Shows spinner during check

### NutritionPanel (`components/products/NutritionPanel.jsx`)
- Renders a structured FDA-style nutrition facts label
- Supports hierarchical nutrients (indentation for sub-categories)
- Bold formatting for calories

### IngredientMap (`components/products/IngredientMap.jsx`)
- Expandable accordion for each ingredient
- Shows source and health benefit per ingredient

---

## 📝 Notes

- Product images are AI-generated in the extreme macro / chiaroscuro style
- The cart persists across sessions via localStorage
- Inquiries submitted via the Contact page are stored in the `Inquiry` entity and trigger a confirmation email
- The site is fully responsive — mobile menu, responsive grids, adaptive layouts