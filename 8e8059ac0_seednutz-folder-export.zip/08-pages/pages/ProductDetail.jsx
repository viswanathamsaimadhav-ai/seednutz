import React, { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Minus, Plus, ShoppingBag } from "lucide-react";
import { useCart } from "@/lib/CartContext";
import { Button } from "@/components/ui/button";
import NutritionPanel from "../components/products/NutritionPanel";
import IngredientMap from "../components/products/IngredientMap";
import ProductCard from "../components/products/ProductCard";

export default function ProductDetail() {
  const { id } = useParams();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  const { data: product, isLoading } = useQuery({
    queryKey: ["product", id],
    queryFn: async () => {
      const products = await base44.entities.Product.filter({ id });
      return products[0];
    },
  });

  const { data: relatedProducts = [] } = useQuery({
    queryKey: ["related-products", product?.category],
    queryFn: () =>
      base44.entities.Product.filter(
        { category: product.category },
        "-created_date",
        5
      ),
    enabled: !!product?.category,
  });

  const related = relatedProducts.filter((p) => p.id !== product?.id).slice(0, 4);

  if (isLoading) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen pt-20 flex flex-col items-center justify-center gap-4">
        <p className="font-display text-2xl">Product not found</p>
        <Link to="/products" className="text-primary text-sm font-body tracking-widest uppercase">
          Back to Products
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      {/* Breadcrumb */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-4">
          <Link
            to="/products"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors font-body"
          >
            <ArrowLeft size={14} />
            Back to Products
          </Link>
        </div>
      </div>

      {/* Product detail */}
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          {/* Image section - sticky */}
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6 }}
                className="aspect-square bg-card border border-border overflow-hidden"
              >
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </motion.div>

              {/* Gallery thumbnails */}
              {product.gallery_images?.length > 0 && (
                <div className="flex gap-2 mt-3">
                  {product.gallery_images.map((img, idx) => (
                    <div
                      key={idx}
                      className="w-20 h-20 bg-card border border-border overflow-hidden"
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Product info */}
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <p className="text-xs font-body tracking-[0.3em] uppercase text-primary mb-3">
                {product.category?.replace(/_/g, " ")}
              </p>
              <h1 className="font-display text-4xl lg:text-5xl mb-4">{product.name}</h1>
              {product.nutrient_usp && (
                <div className="inline-block bg-primary/10 border border-primary/20 px-4 py-2 mb-6">
                  <p className="text-sm font-body text-primary tracking-wider">
                    {product.nutrient_usp}
                  </p>
                </div>
              )}
              <p className="text-muted-foreground font-body text-lg leading-relaxed mb-8">
                {product.description}
              </p>

              {/* Dietary tags */}
              {product.dietary_tags?.length > 0 && (
                <div className="mb-8">
                  <p className="text-xs font-body tracking-[0.3em] uppercase text-muted-foreground mb-3">
                    Dietary Information
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {product.dietary_tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1.5 border border-border text-xs font-body tracking-wider uppercase text-foreground"
                      >
                        {tag.replace(/_/g, " ")}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Benefits */}
              {product.benefits?.length > 0 && (
                <div className="mb-8">
                  <p className="text-xs font-body tracking-[0.3em] uppercase text-muted-foreground mb-3">
                    Benefits
                  </p>
                  <ul className="space-y-2">
                    {product.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 bg-primary mt-2 flex-shrink-0" />
                        <span className="text-sm font-body text-foreground">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Price */}
              {product.price != null && (
                <div className="mb-6">
                  <p className="font-display text-3xl text-primary">${product.price.toFixed(2)}</p>
                </div>
              )}

              {/* Packaging */}
              {product.packaging_details && (
                <div className="mb-10">
                  <p className="text-xs font-body tracking-[0.3em] uppercase text-muted-foreground mb-2">
                    Packaging
                  </p>
                  <p className="text-sm font-body text-foreground">
                    {product.packaging_details}
                  </p>
                </div>
              )}

              {/* Add to cart */}
              <div className="mb-10">
                <p className="text-xs font-body tracking-[0.3em] uppercase text-muted-foreground mb-4">
                  Add to Order
                </p>
                <div className="flex items-center gap-4">
                  <div className="flex items-center border border-border">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      className="w-12 h-12 flex items-center justify-center hover:bg-card transition-colors"
                    >
                      <Minus size={15} />
                    </button>
                    <span className="w-12 h-12 flex items-center justify-center text-sm font-body border-x border-border">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => q + 1)}
                      className="w-12 h-12 flex items-center justify-center hover:bg-card transition-colors"
                    >
                      <Plus size={15} />
                    </button>
                  </div>
                  <Button
                    onClick={() => {
                      for (let i = 0; i < quantity; i++) addToCart(product);
                      setQuantity(1);
                    }}
                    className="flex-1 max-w-xs bg-primary text-primary-foreground h-12 text-sm font-body tracking-widest uppercase hover:bg-primary/90 rounded-none"
                  >
                    <ShoppingBag size={16} className="mr-2" />
                    Add to Cart
                  </Button>
                </div>
              </div>

              {/* Divider */}
              <div className="h-px bg-border mb-10" />

              {/* Ingredients */}
              <div className="mb-10">
                <IngredientMap ingredients={product.ingredients} />
              </div>

              {/* Nutrition Facts */}
              <div>
                <p className="text-xs font-body tracking-[0.3em] uppercase text-primary mb-6">
                  Nutrition Facts
                </p>
                <NutritionPanel facts={product.nutrition_facts} />
              </div>

              {/* Inquiry CTA */}
              <div className="mt-12 border border-border p-8">
                <p className="font-display text-xl mb-2">Interested in this product?</p>
                <p className="text-sm text-muted-foreground font-body mb-4">
                  Contact us for wholesale pricing, distribution, or any questions.
                </p>
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-3 bg-primary text-primary-foreground px-6 py-3 text-sm font-body tracking-widest uppercase hover:bg-primary/90 transition-all"
                >
                  Get In Touch
                </Link>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Related products */}
        {related.length > 0 && (
          <div className="mt-24 border-t border-border pt-16">
            <h2 className="font-display text-3xl mb-10">
              Related <span className="text-primary">Products</span>
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {related.map((p, idx) => (
                <ProductCard key={p.id} product={p} index={idx} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}