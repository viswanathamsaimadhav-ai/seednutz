import React, { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { SlidersHorizontal, X } from "lucide-react";
import FilterEngine from "../components/products/FilterEngine";
import ProductCard from "../components/products/ProductCard";
import SearchBar from "../components/products/SearchBar";

export default function Products() {
  const urlParams = new URLSearchParams(window.location.search);
  const initialCategory = urlParams.get("category");

  const [search, setSearch] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    categories: initialCategory ? [initialCategory] : [],
    flavors: [],
    dietary: [],
  });

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["products"],
    queryFn: () => base44.entities.Product.list("-created_date", 100),
  });

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch =
        !search ||
        p.name?.toLowerCase().includes(search.toLowerCase()) ||
        p.description?.toLowerCase().includes(search.toLowerCase());

      const matchesCategory =
        filters.categories.length === 0 ||
        filters.categories.includes(p.category);

      const matchesFlavor =
        filters.flavors.length === 0 || filters.flavors.includes(p.flavor);

      const matchesDietary =
        filters.dietary.length === 0 ||
        filters.dietary.some((d) => p.dietary_tags?.includes(d));

      return matchesSearch && matchesCategory && matchesFlavor && matchesDietary;
    });
  }, [products, search, filters]);

  const clearAll = () => {
    setFilters({ categories: [], flavors: [], dietary: [] });
    setSearch("");
  };

  const activeFilterCount =
    filters.categories.length + filters.flavors.length + filters.dietary.length;

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <p className="text-xs font-body tracking-[0.4em] uppercase text-primary mb-4">
              Catalog
            </p>
            <h1 className="font-display text-5xl lg:text-6xl">
              Our <span className="text-primary">Products</span>
            </h1>
            <p className="mt-4 text-muted-foreground font-body text-lg max-w-xl">
              Discover our complete range of premium nuts, seeds, and blends.
              Filter by category, flavor, or dietary needs.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
        {/* Search and filter toggle */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="flex-1">
            <SearchBar value={search} onChange={setSearch} />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`inline-flex items-center gap-2 px-6 py-3 border text-sm font-body tracking-widest uppercase transition-all duration-300 ${
              showFilters || activeFilterCount > 0
                ? "border-primary text-primary"
                : "border-border text-muted-foreground hover:border-primary/50"
            }`}
          >
            <SlidersHorizontal size={16} />
            Filters
            {activeFilterCount > 0 && (
              <span className="bg-primary text-primary-foreground text-[10px] px-1.5 py-0.5 ml-1">
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>

        {/* Filters panel */}
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="border border-border p-6 mb-8"
          >
            <FilterEngine
              filters={filters}
              onFilterChange={setFilters}
              onClearAll={clearAll}
            />
          </motion.div>
        )}

        {/* Results count */}
        <div className="mb-8 flex items-center justify-between">
          <p className="text-sm text-muted-foreground font-body">
            {filteredProducts.length} product{filteredProducts.length !== 1 ? "s" : ""}
          </p>
          {activeFilterCount > 0 && (
            <button
              onClick={clearAll}
              className="flex items-center gap-1.5 text-xs text-primary hover:text-foreground transition-colors"
            >
              <X size={12} />
              Clear filters
            </button>
          )}
        </div>

        {/* Product grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {Array(8)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="aspect-square bg-card mb-4" />
                  <div className="h-3 bg-card w-16 mb-2" />
                  <div className="h-5 bg-card w-32" />
                </div>
              ))}
          </div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredProducts.map((product, idx) => (
              <ProductCard key={product.id} product={product} index={idx} />
            ))}
          </div>
        ) : (
          <div className="text-center py-24">
            <p className="font-display text-2xl text-muted-foreground">
              No products found
            </p>
            <p className="text-sm text-muted-foreground font-body mt-2">
              Try adjusting your filters or search terms
            </p>
          </div>
        )}
      </div>
    </div>
  );
}