// Placeholder file: ScrollToTop.jsx
