// Placeholder file: FeaturedCategories.jsx
