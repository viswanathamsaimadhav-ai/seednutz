// Placeholder file: AdminGuard.jsx
